// All data now comes from Supabase database
// This file is kept for compatibility but should not be used

export const mockUsers: any[] = [];
export const mockChecklists: any[] = [];
export const mockRequests: any[] = [];
export const mockMessages: any[] = [];
export const mockAlerts: any[] = [];